#!/bin/sh
cd /root/results/gpr-chunk-root/kept-output/allocation-probe/fixed
exec /root/results/gpr-chunk-root/kept-output/bin/simd-0 --contenders blake3-servil-st --points "lent 64 B" --for-regression-check --rounds 2 >run.out 2>run.err
