#!/bin/sh
cd /root/results/gpr-chunk-root/kept-output/allocation-probe/original
exec /root/results/gpr-chunk-root/devon-output-integration/simd --contenders blake3-servil-st --points "lent 64 B" --for-regression-check --rounds 2 >run.out 2>run.err
