#!/bin/sh
exec env DIAG_DIRECT_PLANT_ACTIVE=1 /root/results/afk-20261024-runtime-control/bin/control-b/bench-11 "$@"
