#!/bin/sh
exec env DIAG_DIRECT_PLANT_ACTIVE=0 /root/results/afk-20261024-runtime-control/bin/control-a/bench-15 "$@"
