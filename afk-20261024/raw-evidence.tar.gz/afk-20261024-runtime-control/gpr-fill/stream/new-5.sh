#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/gpr-fill/bench-5 --threads 4 "$@"
