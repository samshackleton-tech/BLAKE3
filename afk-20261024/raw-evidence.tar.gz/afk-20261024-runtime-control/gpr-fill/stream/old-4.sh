#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-fill/bench-4 --threads 4 "$@"
