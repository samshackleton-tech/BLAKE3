#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/gpr-fill/bench-15 --threads 4 "$@"
