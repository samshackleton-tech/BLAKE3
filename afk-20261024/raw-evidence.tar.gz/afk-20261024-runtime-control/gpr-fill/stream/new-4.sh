#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/gpr-fill/bench-4 --threads 4 "$@"
