#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-fill/bench-14 --threads 4 "$@"
