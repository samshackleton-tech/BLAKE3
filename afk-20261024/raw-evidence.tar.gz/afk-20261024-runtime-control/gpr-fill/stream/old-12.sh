#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-fill/bench-12 --threads 4 "$@"
