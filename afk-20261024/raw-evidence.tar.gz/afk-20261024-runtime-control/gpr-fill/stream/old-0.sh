#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-fill/bench-0 --threads 4 "$@"
