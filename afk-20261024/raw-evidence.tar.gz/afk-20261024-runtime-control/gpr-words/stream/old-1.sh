#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-words/bench-1 --threads 4 "$@"
