#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/gpr-words/bench-6 --threads 4 "$@"
