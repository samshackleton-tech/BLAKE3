#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-words/bench-2 --threads 4 "$@"
