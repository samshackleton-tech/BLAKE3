#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-words/bench-10 --threads 4 "$@"
