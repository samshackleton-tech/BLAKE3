#!/bin/sh
exec /root/results/afk-20261024-runtime-control/bin/simd-words/bench-9 --threads 4 "$@"
