#!/bin/sh
exec /root/results/afk-20261024-runtime-control/activation/new-zero/bench-12.sh --threads 4 "$@"
