#!/bin/sh
exec /root/results/afk-20261024-runtime-control/activation/old-zero/bench-6.sh --threads 4 "$@"
