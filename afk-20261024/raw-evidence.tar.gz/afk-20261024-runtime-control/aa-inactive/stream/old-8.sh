#!/bin/sh
exec /root/results/afk-20261024-runtime-control/activation/old-zero/bench-8.sh --threads 4 "$@"
