#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-a/bench-3 --threads 4 "$@"
