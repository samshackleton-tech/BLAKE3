#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-b/bench-1 --threads 4 "$@"
