#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-a/bench-2 --threads 4 "$@"
