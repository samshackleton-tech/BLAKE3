#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-a/bench-14 --threads 4 "$@"
