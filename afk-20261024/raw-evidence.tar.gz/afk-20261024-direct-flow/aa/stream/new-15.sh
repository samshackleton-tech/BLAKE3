#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-b/bench-15 --threads 4 "$@"
