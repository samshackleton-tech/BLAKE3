#!/bin/sh
exec /root/results/afk-20261024-direct-flow/bin/simd-b/bench-6 --threads 4 "$@"
