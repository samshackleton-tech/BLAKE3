#!/bin/bash
set -euo pipefail
. /root/.cargo/env
ulimit -c 0
r=/root/results/release-api-capi-guards-20261025
exec > "$r/runner.log" 2>&1
trap 'echo "API C guards exit=$? $(date -Is)" >> "$r/status.log"' EXIT
cd /root/BLAKE3-api-capi-guards
[ "$(git rev-parse HEAD)" = ba9e9a3b454181e999bfa01ae83fe31b91b28223 ]
(CARGO_TARGET_DIR=/root/target-api-capi-guards-native cargo nextest run --release --manifest-path capi/Cargo.toml > "$r/native.log" 2>&1) & native=$!
(RUSTUP_TOOLCHAIN=nightly-2026-10-24 CARGO_TARGET_DIR=/root/target-api-capi-guards-miri python3 tools/test_capi_guards.py > "$r/miri.log" 2>&1) & miri=$!
result=0
for pid in "$native" "$miri"; do wait "$pid" || result=1; done
[ "$result" = 0 ]
echo "two-kinds C guard suite complete $(date -Is)" >> "$r/status.log"
