use std::ffi::c_void;
use std::mem::MaybeUninit;

#[repr(align(64))]
struct Input([u8; 128]);

unsafe extern "C" fn done(_: *mut c_void, _: *mut capi::Digest, count: usize) {
    assert_eq!(count, 1);
}

struct Context {
    stream: *mut capi::B3Stream,
    entered: bool,
}

unsafe extern "C" fn reenter(ctx: *mut c_void, _: *mut capi::Digest, _: usize) {
    let ctx = unsafe { &mut *ctx.cast::<Context>() };
    if !ctx.entered {
        ctx.entered = true;
        // Deliberately invalid control: the outer C entry still borrows this stream.
        unsafe { capi::b3_stream_collect(ctx.stream) };
    }
}

fn main() {
    let case = std::env::args().nth(1).expect("case");
    if case == "uninitialized-read-control" {
        let storage = MaybeUninit::<u8>::uninit();
        let byte = unsafe { storage.assume_init() };
        println!("{byte}");
        return;
    }
    let mode = capi::b3_plain();
    let mut input = Input([42; 128]);
    match case.as_str() {
        "batch-initialized" | "batch-uninitialized" => {
            let mut output = MaybeUninit::<[capi::Digest; 2]>::uninit();
            if case == "batch-initialized" {
                output.write([capi::Digest { bytes: [0; 32] }; 2]);
            }
            unsafe { capi::b3_hash_many(&mode, input.0.as_ptr().cast(), 64, 2, output.as_mut_ptr().cast()) };
            let output = unsafe { output.assume_init() };
            assert_eq!(output[0].bytes, b3::hash(&input.0[..64]).as_bytes()[..]);
            assert_eq!(output[1].bytes, b3::hash(&input.0[64..]).as_bytes()[..]);
        }
        "batch-overlap-control" => {
            let pointer = input.0.as_mut_ptr();
            // Deliberately overlapping initialized regions; interpret only under Miri.
            unsafe { capi::b3_hash_many(&mode, pointer.cast(), 64, 2, pointer.cast()) };
        }
        "xof-initialized" | "xof-uninitialized" => {
            let mut hasher = MaybeUninit::<capi::B3Hasher>::uninit();
            let mut output = MaybeUninit::<[u8; 33]>::uninit();
            if case == "xof-initialized" {
                output.write([0; 33]);
            }
            unsafe {
                capi::b3_hasher_init(hasher.as_mut_ptr(), &mode);
                capi::b3_hasher_update(hasher.as_mut_ptr(), input.0.as_ptr().cast(), 64);
                capi::b3_hasher_output(hasher.as_ptr(), 0, output.as_mut_ptr().cast(), 33);
            }
            let output = unsafe { output.assume_init() };
            let mut expected = [0; 33];
            b3::Hasher::new().update(&input.0[..64]).finalize_xof().fill(&mut expected);
            assert_eq!(output, expected);
        }
        "stream-initialized" | "stream-uninitialized" | "stream-reentry-control" => {
            let mut output = MaybeUninit::<capi::Digest>::uninit();
            if case != "stream-uninitialized" {
                output.write(capi::Digest { bytes: [0; 32] });
            }
            let mut context = Context { stream: std::ptr::null_mut(), entered: false };
            let stream = if case == "stream-reentry-control" {
                unsafe { capi::b3_stream_begin(&mode, reenter, (&mut context as *mut Context).cast()) }
            } else {
                unsafe { capi::b3_stream_begin(&mode, done, std::ptr::null_mut()) }
            };
            context.stream = stream;
            unsafe {
                capi::b3_stream_submit(stream, input.0.as_ptr().cast(), 64, output.as_mut_ptr());
                capi::b3_stream_finish(stream);
            }
            assert_eq!(unsafe { output.assume_init() }.bytes, b3::hash(&input.0[..64]).as_bytes()[..]);
        }
        _ => panic!("unknown case"),
    }
    println!("case completed: {case}");
}
